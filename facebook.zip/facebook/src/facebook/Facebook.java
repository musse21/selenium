
package Facebook;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author i3
 */
public class Facebook {

    public static void main(String[] args) throws FileNotFoundException, IOException {

                System.setProperty("webdriver.chrome.driver", "C://chromedriver.exe");

                Scanner reader = new Scanner(System.in);
              
                System.out.println("Email: ");
                
                String email = reader.next(); 
                
                System.out.println("Password: ");
                
                String password = reader.next();
       
        WebDriver drive = new ChromeDriver();
        JavascriptExecutor njse = (JavascriptExecutor)drive;
        drive.get("https://www.facebook.com/");
        drive.findElement(By.id("email")).sendKeys(email);
        drive.findElement(By.id("pass")).sendKeys(password);
        drive.findElement(By.id("loginbutton")).click();
             try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                
            }
        drive.findElement(By.xpath("//*[@id=\"u_0_4\"]/div[1]/div[1]/div/a")).click();
        
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                
            }
                                
        drive.findElement(By.xpath("//div[@id='fbTimelineHeadline']/div[2]/div/div/a[3]")).click();
       
            try {
            
                Thread.sleep(3000);
         
            } catch (InterruptedException e) {
                
            }
            
        String str = (drive.findElement(By.xpath("//div[@id='fbTimelineHeadline']/div[2]/div/div/a[3]/span[1]"))).getText();
        
        System.out.println("Number of Friends: " + str);
         
             try {
                
                 Thread.sleep(3000);
                
            } catch (InterruptedException e) {
                
            }
     while(true)
         
         try{   
             njse.executeScript("scroll(0,100000);");
             
            break;
         }
     catch(Throwable T){
     
     }
     
    }
}
